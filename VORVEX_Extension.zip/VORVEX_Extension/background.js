const BRIDGE_URL = "http://127.0.0.1:7865";
let backendFailStreak = 0;

async function openTabSafely(url) {
  for (let i = 0; i < 15; i++) {
    try {
      return await chrome.tabs.create({ url, active: true });
    } catch (e) {
      await new Promise(r => setTimeout(r, 300));
    }
  }
  return null;
}

async function isBackendAlive() {
  try {
    const res = await fetch(`${BRIDGE_URL}/ping`, { method: "GET" });
    if (res.ok) {
      backendFailStreak = 0;
      return true;
    }
  } catch (e) {}
  backendFailStreak++;
  if (backendFailStreak >= 3) {
    await chrome.storage.local.remove(["vorvex_job"]);
    return false;
  }
  return true;
}

async function reportStatus(payload) {
  try {
    await fetch(`${BRIDGE_URL}/agent_status`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
  } catch (e) {}
}

async function trustedClickAt(tabId, x, y) {
  const target = { tabId };
  try {
    await chrome.debugger.attach(target, "1.3");
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseMoved",
      x: Math.round(x),
      y: Math.round(y)
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x: Math.round(x),
      y: Math.round(y),
      button: "left",
      clickCount: 1
    });
    await new Promise(r => setTimeout(r, 60));
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x: Math.round(x),
      y: Math.round(y),
      button: "left",
      clickCount: 1
    });
  } catch (e) {
  } finally {
    try { await chrome.debugger.detach(target); } catch (e) {}
  }
}

async function trustedRealPasteIntoEditor(tabId, editorX, editorY) {
  const target = { tabId };
  try {
    await chrome.debugger.attach(target, "1.3");
    // 1. Click inside editor box
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mousePressed",
      x: Math.round(editorX),
      y: Math.round(editorY),
      button: "left",
      clickCount: 1
    });
    await new Promise(r => setTimeout(r, 40));
    await chrome.debugger.sendCommand(target, "Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x: Math.round(editorX),
      y: Math.round(editorY),
      button: "left",
      clickCount: 1
    });
    await new Promise(r => setTimeout(r, 120));

    // 2. Real hardware Ctrl+A (modifiers = 2 is Ctrl)
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyDown",
      modifiers: 2,
      windowsVirtualKeyCode: 65,
      code: "KeyA",
      key: "a"
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyUp",
      modifiers: 2,
      windowsVirtualKeyCode: 65,
      code: "KeyA",
      key: "a"
    });
    await new Promise(r => setTimeout(r, 80));

    // 3. Real hardware Ctrl+V (Paste from system clipboard!)
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyDown",
      modifiers: 2,
      windowsVirtualKeyCode: 86,
      code: "KeyV",
      key: "v"
    });
    await chrome.debugger.sendCommand(target, "Input.dispatchKeyEvent", {
      type: "keyUp",
      modifiers: 2,
      windowsVirtualKeyCode: 86,
      code: "KeyV",
      key: "v"
    });
    await new Promise(r => setTimeout(r, 350));
  } catch (e) {
  } finally {
    try { await chrome.debugger.detach(target); } catch (e) {}
  }
}

async function startNewJob(job) {
  if (!job || !job.job_id) return;
  const stored = await chrome.storage.local.get(["last_job_id"]);
  if (stored.last_job_id === job.job_id) return;

  backendFailStreak = 0;
  await chrome.storage.local.set({
    last_job_id: job.job_id,
    vorvex_job: {
      job_id: job.job_id,
      master_prompt: job.master_prompt,
      script: job.script,
      stage: "DEEPSEEK_STEP1",
      continue_clicks: 0,
      scenes: [],
      all_scenes: []
    }
  });

  await reportStatus({
    state: "RUNNING",
    step: "Step 1/7: Opening DeepSeek in New Tab...",
    detail: "Extension connected! Opening DeepSeek in your active Chrome browser..."
  });

  await openTabSafely("https://chat.deepseek.com/");
}

setInterval(async () => {
  try {
    const res = await fetch(`${BRIDGE_URL}/poll_job`, { method: "GET" });
    if (res.ok) {
      backendFailStreak = 0;
      const job = await res.json();
      if (job && job.active && job.job_id) {
        await startNewJob(job);
      }
    }
  } catch (e) {}
}, 1000);

chrome.downloads.onChanged.addListener(async (delta) => {
  if (delta.state && delta.state.current === "complete") {
    const items = await chrome.downloads.search({ id: delta.id });
    if (items && items.length > 0) {
      const file = items[0];
      const fname = (file.filename || "").toLowerCase();
      const url = (file.url || "").toLowerCase();
      if (fname.endsWith(".zip") && (url.includes("flow.google.com") || url.includes("googleapis") || fname.includes("nov") || fname.includes("project") || fname.includes("flow") || fname.includes("jan") || fname.includes("feb") || fname.includes("mar") || fname.includes("apr") || fname.includes("may") || fname.includes("jun") || fname.includes("jul") || fname.includes("aug") || fname.includes("sep") || fname.includes("oct") || fname.includes("dec"))) {
        const data = await chrome.storage.local.get(["vorvex_job"]);
        const job = data.vorvex_job;
        if (job && job.stage === "WAITING_ZIP_DOWNLOAD") {
          job.stage = "VERIFYING_IMAGES";
          await chrome.storage.local.set({ vorvex_job: job });
          try {
            const resp = await fetch(`${BRIDGE_URL}/process_zip_rename`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                zip_path: file.filename,
                all_scenes: job.all_scenes || job.scenes || []
              })
            });
            const result = await resp.json();
            if (result && result.status === "MISSING_IMAGES" && Array.isArray(result.missing_scenes) && result.missing_scenes.length > 0) {
              const freshRecoveryJob = {
                job_id: job.job_id + "_retry_" + Date.now(),
                stage: "FLOW_SETUP",
                scenes: result.missing_scenes,
                all_scenes: job.all_scenes || job.scenes || [],
                flow_settings_saved: false,
                flow_init_confirmed: false,
                flow_completed_batches: 0,
                flow_error_reloads: {}
              };
              await chrome.storage.local.set({ vorvex_job: freshRecoveryJob });
              await openTabSafely("https://flow.google.com/");
            } else {
              job.stage = "DONE";
              await chrome.storage.local.set({ vorvex_job: job });
            }
          } catch (e) {}
        }
      }
    }
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "CHECK_BACKEND") {
    isBackendAlive().then(alive => sendResponse({ alive }));
    return true;
  } else if (msg.type === "START_JOB_DIRECT") {
    startNewJob(msg.payload);
  } else if (msg.type === "STATUS_UPDATE") {
    reportStatus(msg.payload);
  } else if (msg.type === "SCENES_READY") {
    chrome.storage.local.get(["vorvex_job"]).then(d => {
      if (d.vorvex_job) {
        d.vorvex_job.all_scenes = msg.scenes || [];
        chrome.storage.local.set({ vorvex_job: d.vorvex_job });
      }
    });
    fetch(`${BRIDGE_URL}/start_auto_timestamps`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ scenes: msg.scenes || [] })
    }).catch(() => {});
  } else if (msg.type === "OPEN_FLOW") {
    openTabSafely("https://flow.google.com/");
  } else if (msg.type === "TRUSTED_CLICK" && sender.tab && sender.tab.id) {
    trustedClickAt(sender.tab.id, msg.x, msg.y);
  } else if (msg.type === "TRUSTED_PASTE" && sender.tab && sender.tab.id) {
    trustedRealPasteIntoEditor(sender.tab.id, msg.x, msg.y).then(() => sendResponse({ ok: true }));
    return true;
  }
});