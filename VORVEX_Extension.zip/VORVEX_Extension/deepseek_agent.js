(function () {
  let isRunning = false;

  async function checkBackendStillRunning() {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: "CHECK_BACKEND" }, (res) => {
          if (chrome.runtime.lastError) return resolve(false);
          resolve(!!(res && res.alive));
        });
      } catch (e) {
        resolve(false);
      }
    });
  }

  function sendStatus(state, step, detail, problem = false) {
    try {
      chrome.runtime.sendMessage({
        type: "STATUS_UPDATE",
        payload: { state, step, detail, problem }
      });
    } catch (e) {}
  }

  function simulateFullReactClick(el) {
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;
    const opts = {
      bubbles: true,
      cancelable: true,
      view: window,
      clientX: cx,
      clientY: cy,
      button: 0,
      buttons: 1
    };
    try { el.focus(); } catch (e) {}
    el.dispatchEvent(new PointerEvent("pointerdown", opts));
    el.dispatchEvent(new MouseEvent("mousedown", opts));
    el.dispatchEvent(new PointerEvent("pointerup", opts));
    el.dispatchEvent(new MouseEvent("mouseup", opts));
    el.dispatchEvent(new MouseEvent("click", opts));
    el.click();
    el.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
  }

  function injectReactTextarea(ta, text) {
    ta.focus();
    const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
    setter.call(ta, text);
    ta.dispatchEvent(new Event("input", { bubbles: true }));
  }

  function getSendStopButton() {
    const ta = document.querySelector("textarea");
    if (!ta) return null;
    let container = ta.parentElement;
    for (let lvl = 0; lvl < 4 && container; lvl++) {
      const btns = Array.from(container.querySelectorAll('div[role="button"].ds-icon-button, div[role="button"], button'));
      for (let i = btns.length - 1; i >= 0; i--) {
        const btn = btns[i];
        const cls = (btn.className || "").toString();
        const r = btn.getBoundingClientRect();
        if (r.width >= 26 && r.width <= 46 && r.height >= 26 && r.height <= 46 && !cls.includes("ds-button--floating")) {
          return btn;
        }
      }
      container = container.parentElement;
    }
    return null;
  }

  function clickSendButton() {
    const btn = getSendStopButton();
    if (!btn) return false;
    const cls = (btn.className || "").toString();
    const disabled = btn.getAttribute("aria-disabled") === "true" || btn.disabled || cls.includes("ds-button--disabled");
    if (!disabled) {
      simulateFullReactClick(btn);
      return true;
    }
    return false;
  }

  function isGenerating() {
    const btn = getSendStopButton();
    if (!btn) return false;
    const cls = (btn.className || "").toString();
    if (cls.includes("ds-button--disabled") || btn.getAttribute("aria-disabled") === "true") {
      return false;
    }
    return !!btn.querySelector("rect");
  }

  function clickYellowRetryIfVisible() {
    const warnBtns = Array.from(document.querySelectorAll('div[role="button"].ds-button--warning, button.ds-button--warning'));
    for (const wb of warnBtns) {
      const r = wb.getBoundingClientRect();
      if (r.width > 10 && r.height > 10) {
        wb.scrollIntoView({ behavior: "instant", block: "center" });
        const cx = r.left + r.width / 2;
        const cy = r.top + r.height / 2;
        chrome.runtime.sendMessage({ type: "TRUSTED_CLICK", x: cx, y: cy });
        simulateFullReactClick(wb);
        return true;
      }
    }
    return false;
  }

  function clickContinueIfVisible() {
    // Broadened selector across all buttons, role="button" divs, and ds-button spans (Screenshot 641)
    const candidates = Array.from(document.querySelectorAll('span.ds-button__content, div[role="button"], button, span'));
    for (const el of candidates) {
      const txt = (el.textContent || "").trim();
      if (txt === "Continue") {
        const clickable = el.closest('div[role="button"], button') || el;
        const r = clickable.getBoundingClientRect();
        if (r.width > 25 && r.height > 14 && r.width < 220) {
          clickable.scrollIntoView({ behavior: "instant", block: "center" });
          const freshRect = clickable.getBoundingClientRect();
          const cx = freshRect.left + freshRect.width / 2;
          const cy = freshRect.top + freshRect.height / 2;
          chrome.runtime.sendMessage({ type: "TRUSTED_CLICK", x: cx, y: cy });
          simulateFullReactClick(clickable);
          return true;
        }
      }
    }
    return false;
  }

  function clickScrollIfVisible() {
    const scrollBtn = document.querySelector(".ds-button--floating");
    if (scrollBtn) {
      const r = scrollBtn.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) {
        simulateFullReactClick(scrollBtn);
        return true;
      }
    }
    return false;
  }

  function isStoryboardTrulyComplete() {
    if (isGenerating()) return false;
    const bodyTxt = document.body ? document.body.innerText : "";
    const lines = bodyTxt.split("\n").map(l => l.trim()).filter(Boolean);
    for (let i = lines.length - 1; i >= Math.max(0, lines.length - 12); i--) {
      const line = lines[i];
      if (/^SCRIPT COMPLETE\s*[—–\-:]?\s*total scenes:\s*\d+\s*$/i.test(line)) {
        return true;
      }
    }
    return false;
  }

  function extractAllScenesFromPage() {
    const bodyTxt = document.body ? document.body.innerText : "";
    const sceneBlocks = bodyTxt.split(/(?=\bSCENE\s+\d+\b)/i);
    const parsed = [];
    const seen = new Set();

    for (const block of sceneBlocks) {
      const numMatch = block.match(/^SCENE\s+(\d+)\b/i);
      if (!numMatch) continue;
      const num = parseInt(numMatch[1], 10);
      if (seen.has(num)) continue;

      const voiceMatch = block.match(/VOICE LINE:\s*["“]?([\s\S]*?)["”]?\s*\nCOVERS:/i);
      const promptMatch = block.match(/IMAGE PROMPT:\s*([\s\S]*?)(?=\n\s*(?:SCENE\s+\d+|SCRIPT COMPLETE|$))/i);

      if (voiceMatch && promptMatch) {
        seen.add(num);
        parsed.push({
          scene_num: num,
          label: `SCENE ${num}`,
          voice_line: voiceMatch[1].trim().replace(/^["“]|["”]$/g, ""),
          image_prompt: promptMatch[1].trim()
        });
      }
    }
    parsed.sort((a, b) => a.scene_num - b.scene_num);
    return parsed;
  }

  async function runDeepSeekBrain() {
    if (isRunning) return;
    if (!(await checkBackendStillRunning())) return;

    const data = await chrome.storage.local.get(["vorvex_job"]);
    const job = data.vorvex_job;
    if (!job || !job.master_prompt || job.stage === "DONE" || job.stage === "FLOW_SETUP" || job.stage === "WAITING_ZIP_DOWNLOAD") return;

    isRunning = true;

    let ta = null;
    for (let i = 0; i < 35; i++) {
      if (!(await checkBackendStillRunning())) { isRunning = false; return; }
      ta = document.querySelector("textarea");
      if (ta) break;
      await new Promise(r => setTimeout(r, 1000));
    }

    if (!ta) {
      isRunning = false;
      sendStatus("PROBLEM", "⚠️ Problem: DeepSeek Not Logged In or Slow Network", "Could not find DeepSeek chat box. Please check your login or internet.", true);
      return;
    }

    if (job.stage === "DEEPSEEK_STEP1") {
      sendStatus("RUNNING", "Step 1/7: Injecting Master Prompt & Waiting for ROLE.txt...", "Waiting dynamically until DeepSeek enables the Send button...");
      injectReactTextarea(ta, job.master_prompt);

      let sent = false;
      for (let i = 0; i < 60; i++) {
        if (!(await checkBackendStillRunning())) { isRunning = false; return; }
        await new Promise(r => setTimeout(r, 500));
        if (clickSendButton()) {
          sent = true;
          break;
        }
      }

      if (!sent) {
        isRunning = false;
        sendStatus("PROBLEM", "⚠️ Problem: Could Not Send Master Prompt", "Send button stayed disabled in DeepSeek. Please check the screen.", true);
        return;
      }

      job.stage = "DEEPSEEK_WAIT_READY";
      await chrome.storage.local.set({ vorvex_job: job });
      sendStatus("RUNNING", "Step 2/7: Master Prompt Sent! Waiting for 'Ready' Reply...", "Watching DeepSeek DOM for confirmation before sending your script...");
    }

    if (job.stage === "DEEPSEEK_WAIT_READY") {
      let ready = false;
      for (let i = 0; i < 60; i++) {
        if (!(await checkBackendStillRunning())) { isRunning = false; return; }
        await new Promise(r => setTimeout(r, 1000));
        clickYellowRetryIfVisible();
        const txt = document.body ? document.body.innerText : "";
        if (!isGenerating() && (txt.includes("Send the script") || txt.includes("Ready."))) {
          ready = true;
          await new Promise(r => setTimeout(r, 800));
          break;
        }
      }

      if (!ready) {
        isRunning = false;
        sendStatus("PROBLEM", "⚠️ Problem: DeepSeek Did Not Reply Ready", "Timed out waiting for DeepSeek confirmation.", true);
        return;
      }

      ta = document.querySelector("textarea");
      injectReactTextarea(ta, job.script);

      let scriptSent = false;
      for (let i = 0; i < 40; i++) {
        if (!(await checkBackendStillRunning())) { isRunning = false; return; }
        await new Promise(r => setTimeout(r, 500));
        if (clickSendButton()) {
          scriptSent = true;
          break;
        }
      }

      if (!scriptSent) {
        isRunning = false;
        sendStatus("PROBLEM", "⚠️ Problem: Could Not Send Script", "Failed to click Send after pasting script.", true);
        return;
      }

      job.stage = "DEEPSEEK_STREAMING";
      await chrome.storage.local.set({ vorvex_job: job });
      sendStatus("RUNNING", "Step 3/7: Script Sent! Generating All Scene Prompts...", "DOM-Brain is active: auto-clicks Yellow Retry, floating scroll & every Continue button!");
    }

    if (job.stage === "DEEPSEEK_STREAMING") {
      await new Promise(r => setTimeout(r, 3000));
      let idleStreak = 0;
      let typedContinueFallback = false;

      for (let tick = 0; tick < 2400; tick++) {
        if (!(await checkBackendStillRunning())) { isRunning = false; return; }
        await new Promise(r => setTimeout(r, 1500));

        // 1. Yellow Retry button check
        if (clickYellowRetryIfVisible()) {
          idleStreak = 0;
          typedContinueFallback = false;
          sendStatus("RUNNING", "⚡ Auto-Clicked Yellow 'Retry' Button — Recovering DeepSeek Generation...", "Detected temporary DeepSeek message busy warning and clicked Retry automatically!");
          await new Promise(r => setTimeout(r, 3500));
          continue;
        }

        // 2. Click floating downward scroll button whenever it appears
        clickScrollIfVisible();

        // 3. Click 'Continue' button whenever it appears (no matter how many times!)
        if (clickContinueIfVisible()) {
          job.continue_clicks = (job.continue_clicks || 0) + 1;
          idleStreak = 0;
          typedContinueFallback = false;
          await chrome.storage.local.set({ vorvex_job: job });
          sendStatus("RUNNING", `⚡ Clicked 'Continue' (${job.continue_clicks}x) — Generating Remaining Scenes...`, "Detected Continue button in DOM and clicked it immediately!");
          await new Promise(r => setTimeout(r, 3500));
          continue;
        }

        // 4. Check for true completion
        if (isStoryboardTrulyComplete()) {
          await new Promise(r => setTimeout(r, 1000));
          const extractedScenes = extractAllScenesFromPage();
          job.scenes = extractedScenes;
          job.stage = "FLOW_SETUP";
          await chrome.storage.local.set({ vorvex_job: job });
          isRunning = false;

          chrome.runtime.sendMessage({ type: "SCENES_READY", scenes: extractedScenes });

          sendStatus("RUNNING", `Step 4/7: Extracted ${extractedScenes.length} Scenes — Starting Auto Timestamps & Google Flow...`, `Auto Timestamps started in background for all ${extractedScenes.length} voice lines! Opening Google Flow now...`);
          chrome.runtime.sendMessage({ type: "OPEN_FLOW" });
          return;
        }

        if (isGenerating()) {
          idleStreak = 0;
          typedContinueFallback = false;
        } else {
          idleStreak++;

          // Fallback at ~45s idle: if Continue button wasn't clicked by DOM, type "Continue" and send!
          if (idleStreak === 30 && !typedContinueFallback) {
            const box = document.querySelector("textarea");
            if (box) {
              typedContinueFallback = true;
              injectReactTextarea(box, "Continue");
              await new Promise(r => setTimeout(r, 400));
              if (clickSendButton()) {
                job.continue_clicks = (job.continue_clicks || 0) + 1;
                await chrome.storage.local.set({ vorvex_job: job });
                sendStatus("RUNNING", `⚡ Sent 'Continue' (${job.continue_clicks}x) — Resuming Storyboard...`, "Resumed DeepSeek storyboard generation automatically!");
                await new Promise(r => setTimeout(r, 3500));
                continue;
              }
            }
          }

          if (idleStreak >= 65) {
            isRunning = false;
            sendStatus("PROBLEM", "⚠️ Problem: DeepSeek Stopped Unexpectedly", "DeepSeek stopped generating without Continue or SCRIPT COMPLETE. Please check the screen.", true);
            return;
          }
        }
      }
    }
    isRunning = false;
  }

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.vorvex_job) {
      runDeepSeekBrain();
    }
  });

  setTimeout(runDeepSeekBrain, 1000);
})();