(function () {
  const FLOW_INIT_PROMPT = `Generate every image prompt I provide with the highest possible quality and accuracy. Maintain perfect character consistency and keep all objects and details consistent throughout every image. Rename every generated image correctly using its corresponding scene number, such as scene1, scene2, scene3, and so on. Use the exact scene name written with each prompt.If you are 100% ready, reply with ONLY this sentence: "I'm Ready".`;

  async function checkBackendStillRunning() {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type: "CHECK_BACKEND" }, (res) => {
          if (chrome.runtime.lastError) return resolve(false);
          resolve(!!(res && res.alive));
        });
      } catch (e) {
        resolve(false);
      }
    });
  }

  function sendStatus(state, step, detail, problem = false) {
    try {
      chrome.runtime.sendMessage({
        type: "STATUS_UPDATE",
        payload: { state, step, detail, problem }
      });
    } catch (e) {}
  }

  async function trustedClickOnly(el) {
    if (!el) return;
    el.scrollIntoView({ behavior: "instant", block: "nearest" });
    await new Promise(r => setTimeout(r, 120));
    const r = el.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) {
      chrome.runtime.sendMessage({
        type: "TRUSTED_CLICK",
        x: r.left + r.width / 2,
        y: r.top + r.height / 2
      });
      await new Promise(r => setTimeout(r, 300));
    }
  }

  async function trustedAndDomClick(el) {
    if (!el) return;
    el.scrollIntoView({ behavior: "instant", block: "nearest" });
    await new Promise(r => setTimeout(r, 120));
    const r = el.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) {
      chrome.runtime.sendMessage({
        type: "TRUSTED_CLICK",
        x: r.left + r.width / 2,
        y: r.top + r.height / 2
      });
      await new Promise(r => setTimeout(r, 250));
    }
    try { el.click(); } catch (e) {}
  }

  function injectProseMirrorText(editor, text) {
    editor.focus();
    document.execCommand("selectAll", false, null);
    document.execCommand("delete", false, null);
    document.execCommand("insertText", false, text);
    editor.dispatchEvent(new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" }));
  }

  function findArrowSendButton() {
    // Strictly finds ONLY the arrow_forward Send button (NEVER clicks the square Stop button!)
    const box = document.querySelector("flow-base-prompt-box") || document.body;
    const btns = Array.from(box.querySelectorAll("button"));
    for (let i = btns.length - 1; i >= 0; i--) {
      const b = btns[i];
      const icon = (b.querySelector("mat-icon")?.textContent || "").trim();
      const aria = (b.getAttribute("aria-label") || "").toLowerCase();
      const r = b.getBoundingClientRect();
      if (r.width > 15 && r.height > 15 && (icon === "arrow_forward" || icon === "send")) {
        if (!aria.includes("stop") && !aria.includes("cancel") && !b.querySelector("rect")) {
          return b;
        }
      }
    }
    return null;
  }

  function isFlowAgentBusy() {
    const box = document.querySelector("flow-base-prompt-box") || document.body;

    // 1. Check for Stop icon text or Stop aria-label
    const stopMatIcon = Array.from(box.querySelectorAll("mat-icon")).find(ic => {
      const t = (ic.textContent || "").trim();
      return t === "stop" || t === "stop_circle";
    });
    if (stopMatIcon) return true;

    // 2. Check for white circle Stop button with black square <rect> (Screenshot 643)
    const btns = Array.from(box.querySelectorAll("button"));
    for (const b of btns) {
      const aria = (b.getAttribute("aria-label") || "").toLowerCase();
      const r = b.getBoundingClientRect();
      if (r.width > 15 && r.height > 15) {
        if (aria.includes("stop") || aria.includes("cancel")) return true;
        // Right-most action button containing an SVG <rect> is the Stop square in Flow!
        if (r.left > window.innerWidth * 0.85 && b.querySelector("svg rect")) return true;
      }
    }

    // 3. If arrow_forward send button is NOT visible at all (still thinking/renaming), Flow Agent is still busy!
    if (!findArrowSendButton()) return true;

    return false;
  }

  function getSidebarText() {
    const sidebarEl = document.querySelector("mat-sidenav, aside, flow-project-sidenav-container") || document.body;
    return sidebarEl ? (sidebarEl.innerText || "") : "";
  }

  function countFlowSomethingWentWrongErrors() {
    const sideTxt = getSidebarText();
    const matches = sideTxt.match(/Something went wrong\.\s*Please try again\./gi) || [];
    return matches.length;
  }

  async function sendFlowPromptAtomProof(editor) {
    // Never interrupt if Flow Agent is still busy renaming or thinking!
    while (isFlowAgentBusy()) {
      if (!(await checkBackendStillRunning())) return false;
      await new Promise(r => setTimeout(r, 1000));
    }

    await new Promise(r => setTimeout(r, 600));

    for (let attempt = 0; attempt < 12; attempt++) {
      if (!(await checkBackendStillRunning())) return false;
      const currentEditor = document.querySelector('div.ProseMirror[contenteditable="true"], div[role="textbox"][contenteditable="true"]') || editor;
      const remainingText = (currentEditor?.innerText || "").trim();

      if (remainingText.length === 0 || isFlowAgentBusy()) {
        return true;
      }

      const sendBtn = findArrowSendButton();
      if (sendBtn && !sendBtn.disabled) {
        sendBtn.scrollIntoView({ behavior: "instant", block: "nearest" });
        await new Promise(r => setTimeout(r, 150));
        const r = sendBtn.getBoundingClientRect();
        const cx = r.left + r.width / 2;
        const cy = r.top + r.height / 2;

        chrome.runtime.sendMessage({ type: "TRUSTED_CLICK", x: cx, y: cy });
        await new Promise(r => setTimeout(r, 250));

        if (((currentEditor?.innerText || "").trim().length > 0) && !isFlowAgentBusy()) {
          const freshSendBtn = findArrowSendButton();
          if (freshSendBtn && !freshSendBtn.disabled) {
            freshSendBtn.click();
          }
        }
      }

      await new Promise(r => setTimeout(r, 1100));
    }

    const finalEditor = document.querySelector('div.ProseMirror[contenteditable="true"], div[role="textbox"][contenteditable="true"]') || editor;
    return ((finalEditor?.innerText || "").trim().length === 0) || isFlowAgentBusy();
  }

  function countSidebarFeedbackBars() {
    const sidebarEl = document.querySelector("mat-sidenav, aside, flow-project-sidenav-container") || document.body;
    return Array.from(sidebarEl.querySelectorAll("mat-icon")).filter(ic => {
      const t = (ic.textContent || "").trim();
      return t === "thumb_up" || t === "thumb_up_off_alt" || t === "content_copy";
    }).length;
  }

  async function handleFlowErrorWithSingleReload(job, stepKey, humanStepLabel) {
    job.flow_error_reloads = job.flow_error_reloads || {};
    const alreadyReloaded = !!job.flow_error_reloads[stepKey];

    if (!alreadyReloaded) {
      job.flow_error_reloads[stepKey] = true;
      await chrome.storage.local.set({ vorvex_job: job });
      sendStatus(
        "RUNNING",
        `⚡ Flow Error Detected on ${humanStepLabel} — Refreshing Page Once to Recover...`,
        "Detected 'Something went wrong. Please try again.' — refreshing Flow page once and retrying automatically..."
      );
      await new Promise(r => setTimeout(r, 1200));
      window.location.reload();
      return true;
    }

    sendStatus(
      "PROBLEM",
      `⚠️ Problem: Google Flow Error Persists on ${humanStepLabel}`,
      `Google Flow showed 'Something went wrong. Please try again.' even after refreshing the page on ${humanStepLabel}. Please check the screen.`,
      true
    );
    return false;
  }

  async function triggerProjectZipDownload(job) {
    sendStatus("RUNNING", "Step 6/7: Downloading Project ZIP & Renaming via Auto Timestamps...", "Clicking right-side menu -> Download project -> Download and saving all images to Downloads\\Images...");

    for (let attempt = 0; attempt < 6; attempt++) {
      if (!(await checkBackendStillRunning())) return false;

      let dlMenuItem = Array.from(document.querySelectorAll('button[role="menuitem"], .mat-mdc-menu-panel button')).find(b => {
        const r = b.getBoundingClientRect();
        return r.width > 20 && r.height > 15 && (b.innerText || "").includes("Download project");
      });

      if (!dlMenuItem) {
        const rightMoreBtns = Array.from(document.querySelectorAll("button")).filter(b => {
          const iconTxt = (b.querySelector("mat-icon")?.textContent || "").trim();
          const r = b.getBoundingClientRect();
          return iconTxt === "more_vert" && r.top < 120 && r.left > window.innerWidth * 0.5;
        });
        rightMoreBtns.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);
        const moreBtn = rightMoreBtns[0];

        if (moreBtn) {
          await trustedClickOnly(moreBtn);
          await new Promise(r => setTimeout(r, 1000));
        }

        dlMenuItem = Array.from(document.querySelectorAll('button[role="menuitem"], .mat-mdc-menu-panel button')).find(b => {
          const r = b.getBoundingClientRect();
          return r.width > 20 && r.height > 15 && (b.innerText || "").includes("Download project");
        });
      }

      if (dlMenuItem && !dlMenuItem.disabled && dlMenuItem.getAttribute("aria-disabled") !== "true") {
        await trustedAndDomClick(dlMenuItem);
        await new Promise(r => setTimeout(r, 1400));

        for (let dTry = 0; dTry < 6; dTry++) {
          const overlayRoot = document.querySelector(".cdk-overlay-container, mat-dialog-container") || document.body;
          const confirmSpan = Array.from(overlayRoot.querySelectorAll("span.confirm-label, span.mdc-button__label, button")).find(el => {
            const r = el.getBoundingClientRect();
            return r.width > 20 && r.height > 12 && (el.textContent || "").trim() === "Download";
          });

          if (confirmSpan) {
            const confirmBtn = confirmSpan.closest("button") || confirmSpan;
            job.stage = "WAITING_ZIP_DOWNLOAD";
            await chrome.storage.local.set({ vorvex_job: job });
            await trustedAndDomClick(confirmBtn);
            await new Promise(r => setTimeout(r, 1000));

            const stillOpen = (document.body?.innerText || "").includes("Download project?");
            if (!stillOpen) {
              return true;
            }
          }
          await new Promise(r => setTimeout(r, 600));
        }
      }
      await new Promise(r => setTimeout(r, 2000));
    }
    return false;
  }

  async function ensureAgentOnFirst() {
    for (let attempt = 0; attempt < 5; attempt++) {
      const editorExists = !!document.querySelector('div.ProseMirror[contenteditable="true"], div[role="textbox"][contenteditable="true"]');
      const sidebarOpen = (document.body ? document.body.innerText : "").includes("Untitled session");
      if (editorExists && sidebarOpen) return true;

      const agentBtn = Array.from(document.querySelectorAll("button")).find(b => (b.innerText || "").trim() === "Agent");
      if (agentBtn) {
        const bg = window.getComputedStyle(agentBtn).backgroundColor;
        const pressed = agentBtn.getAttribute("aria-pressed") === "true";
        const isWhiteActive = bg.includes("255, 255, 255") || bg.includes("241, 243, 244") || bg.includes("232, 234, 237");
        if (!pressed && !isWhiteActive) {
          await trustedAndDomClick(agentBtn);
          await new Promise(r => setTimeout(r, 1000));
        }
      }

      const expandBtn = Array.from(document.querySelectorAll("button")).find(b => {
        const lbl = (b.getAttribute("aria-label") || b.getAttribute("title") || b.innerText || "").toLowerCase();
        return lbl.includes("expand") || lbl.includes("open_in_full");
      });
      if (expandBtn) {
        await trustedAndDomClick(expandBtn);
        await new Promise(r => setTimeout(r, 1200));
      }

      await new Promise(r => setTimeout(r, 600));
    }
    return true;
  }

  async function ensureImageAnd1xBulletproof() {
    for (let outer = 0; outer < 3; outer++) {
      let settingsBtn = null;
      for (let i = 0; i < 8; i++) {
        const allBtns = Array.from(document.querySelectorAll("button"));
        settingsBtn = allBtns.find(b => {
          const iconTxt = (b.querySelector("mat-icon")?.textContent || "").trim();
          const aria = (b.getAttribute("aria-label") || "").trim();
          const r = b.getBoundingClientRect();
          return r.width > 10 && r.top > window.innerHeight * 0.5 && (iconTxt === "tune" || aria === "Settings");
        });
        if (!settingsBtn) {
          settingsBtn = document.querySelector("button.settings-trigger-button");
        }
        if (settingsBtn) break;
        await new Promise(r => setTimeout(r, 600));
      }

      if (!settingsBtn) return;

      const isAgentSettingsOpen = () => (document.body?.innerText || "").includes("Agent settings") || !!document.querySelector("button.mat-button-toggle-button");
      if (!isAgentSettingsOpen()) {
        await trustedClickOnly(settingsBtn);
        await new Promise(r => setTimeout(r, 900));
      }

      if ((document.body?.innerText || "").includes("Agent settings")) {
        const x1Buttons = Array.from(document.querySelectorAll("button")).filter(b => (b.innerText || "").trim() === "x1");
        if (x1Buttons.length > 0) {
          await trustedAndDomClick(x1Buttons[0]);
          await new Promise(r => setTimeout(r, 400));
        }
        const saveBtn = Array.from(document.querySelectorAll("button")).find(b => (b.innerText || "").trim() === "Save");
        if (saveBtn) {
          await trustedAndDomClick(saveBtn);
          await new Promise(r => setTimeout(r, 800));
        }
        return;
      }

      for (let t = 0; t < 3; t++) {
        const toggles = Array.from(document.querySelectorAll("button.mat-button-toggle-button"));
        const imgBtn = toggles.find(b => (b.querySelector(".toggle-text")?.textContent || b.innerText || "").trim() === "Image");
        if (!imgBtn || imgBtn.getAttribute("aria-checked") === "true") break;
        await trustedAndDomClick(imgBtn);
        await new Promise(r => setTimeout(r, 600));
      }

      for (let t = 0; t < 3; t++) {
        const toggles = Array.from(document.querySelectorAll("button.mat-button-toggle-button"));
        const ratioBtn = toggles.find(b => (b.querySelector(".toggle-text")?.textContent || b.innerText || "").trim() === "16:9");
        if (!ratioBtn || ratioBtn.getAttribute("aria-checked") === "true") break;
        await trustedAndDomClick(ratioBtn);
        await new Promise(r => setTimeout(r, 450));
      }

      let x1Confirmed = false;
      for (let t = 0; t < 4; t++) {
        const toggles = Array.from(document.querySelectorAll("button.mat-button-toggle-button"));
        const x1Btn = toggles.find(b => (b.querySelector(".toggle-text")?.textContent || b.innerText || "").trim() === "x1");
        if (!x1Btn) break;
        if (x1Btn.getAttribute("aria-checked") === "true") {
          x1Confirmed = true;
          break;
        }
        await trustedAndDomClick(x1Btn);
        await new Promise(r => setTimeout(r, 500));
      }

      const saveBtn = Array.from(document.querySelectorAll("button")).find(b => (b.innerText || "").trim() === "Save");
      if (saveBtn) {
        await trustedAndDomClick(saveBtn);
        await new Promise(r => setTimeout(r, 800));
      } else if (document.querySelector("button.mat-button-toggle-button")) {
        await trustedClickOnly(settingsBtn);
        await new Promise(r => setTimeout(r, 600));
      }

      if (x1Confirmed || (document.body?.innerText || "").includes("x1")) {
        return;
      }
    }
  }

  async function runFlowBrain() {
    if (!(await checkBackendStillRunning())) return;
    const data = await chrome.storage.local.get(["vorvex_job"]);
    const job = data.vorvex_job;
    if (!job) return;

    if (job.stage === "FLOW_RELOADED_DOWNLOAD") {
      for (let i = 0; i < 20; i++) {
        if (!(await checkBackendStillRunning())) return;
        await new Promise(r => setTimeout(r, 1000));
        if ((document.body?.innerText || "").includes("All media")) {
          await new Promise(r => setTimeout(r, 2000));
          break;
        }
      }
      const ok = await triggerProjectZipDownload(job);
      if (!ok && (await checkBackendStillRunning())) {
        sendStatus("PROBLEM", "⚠️ Problem: Could Not Trigger Download Project", "Page refreshed after generating all images, please click right-side 3 dots -> Download project manually.", true);
      }
      return;
    }

    if (job.stage !== "FLOW_SETUP") return;

    const scenes = job.scenes || [];
    const isInsideExistingProject = window.location.href.includes("/project/");

    let ready = false;
    for (let i = 0; i < 25; i++) {
      if (!(await checkBackendStillRunning())) return;
      await new Promise(r => setTimeout(r, 1000));
      const txt = document.body ? document.body.innerText : "";
      if (txt.includes("New project") || txt.includes("What do you want to create?") || txt.includes("Untitled session") || txt.includes("All media")) {
        ready = true;
        break;
      }
    }

    if (!ready) {
      sendStatus("PROBLEM", "⚠️ Problem: Google Flow Did Not Load", "Google Flow took too long or needs sign-in. Please check the screen.", true);
      return;
    }

    await new Promise(r => setTimeout(r, 800));

    // 1. Click '+ New project' if not already inside an active project URL
    if (!isInsideExistingProject) {
      const fabBtns = Array.from(document.querySelectorAll("button.mat-mdc-extended-fab, button"));
      const newProjBtn = fabBtns.find(b => (b.innerText || "").includes("New project"));
      if (newProjBtn) {
        newProjBtn.click();
        for (let i = 0; i < 15; i++) {
          if (!(await checkBackendStillRunning())) return;
          await new Promise(r => setTimeout(r, 1000));
          const txt = document.body ? document.body.innerText : "";
          if (txt.includes("What do you want to create?") || txt.includes("Untitled session")) {
            await new Promise(r => setTimeout(r, 800));
            break;
          }
        }
      }
    }

    // 2. Always turn ON Agent mode first after New Project
    await ensureAgentOnFirst();

    // 3. Always select Image + 16:9 + x1 + Save
    if (!job.flow_settings_saved) {
      await ensureImageAnd1xBulletproof();
      job.flow_settings_saved = true;
      await chrome.storage.local.set({ vorvex_job: job });
    }

    if (scenes.length === 0) {
      job.stage = "DONE";
      await chrome.storage.local.set({ vorvex_job: job });
      sendStatus("DONE", "✓ Google Flow Configured (Agent ON + Image + 1x)!", "Flow is ready with Agent ON, Image mode & 1x output.");
      return;
    }

    // 4. Send initial consistency + scene naming instruction prompt & wait for "I'm Ready"
    const sideTxtInitial = getSidebarText();
    const alreadyReadyMatches = sideTxtInitial.match(/I['’]m Ready/gi) || [];
    if (!job.flow_init_confirmed && alreadyReadyMatches.length < 2) {
      sendStatus("RUNNING", "Step 5/7: Initializing Flow Agent & Waiting for \"I'm Ready\"...", "Sending consistency & scene-naming instructions to Google Flow Agent...");

      let editor = document.querySelector('div.ProseMirror[contenteditable="true"], div[role="textbox"][contenteditable="true"]');
      if (!editor) {
        sendStatus("PROBLEM", "⚠️ Problem: Flow Agent Input Box Not Found", "Could not locate 'What do you want to create?' editor in Google Flow.", true);
        return;
      }

      const errorsBeforeInit = countFlowSomethingWentWrongErrors();
      injectProseMirrorText(editor, FLOW_INIT_PROMPT);
      const initSent = await sendFlowPromptAtomProof(editor);
      if (!initSent) {
        if (await checkBackendStillRunning()) {
          sendStatus("PROBLEM", "⚠️ Problem: Could Not Click Send in Flow", "Failed to send initial prompt in Google Flow.", true);
        }
        return;
      }

      let flowConfirmedReady = false;
      await new Promise(r => setTimeout(r, 2500));
      for (let w = 0; w < 45; w++) {
        if (!(await checkBackendStillRunning())) return;
        await new Promise(r => setTimeout(r, 1000));

        if (!isFlowAgentBusy() && countFlowSomethingWentWrongErrors() > errorsBeforeInit) {
          await handleFlowErrorWithSingleReload(job, "init_prompt", "Initial Setup Prompt");
          return;
        }

        const sideTxt = getSidebarText();
        const matches = sideTxt.match(/I['’]m Ready/gi) || [];
        if (!isFlowAgentBusy() && matches.length >= 2) {
          flowConfirmedReady = true;
          job.flow_init_confirmed = true;
          await chrome.storage.local.set({ vorvex_job: job });
          await new Promise(r => setTimeout(r, 500));
          break;
        }
      }

      if (!flowConfirmedReady) {
        sendStatus("PROBLEM", "⚠️ Problem: Flow Agent Did Not Reply I'm Ready", "Google Flow Agent did not respond with I'm Ready. Please check the screen.", true);
        return;
      }
    }

    // 5. Pre-build ALL 20-scene batches in memory upfront
    const BATCH_SIZE = 20;
    const prebuiltBatches = [];
    for (let i = 0; i < scenes.length; i += BATCH_SIZE) {
      const slice = scenes.slice(i, i + BATCH_SIZE);
      prebuiltBatches.push({
        startScene: slice[0].scene_num,
        endScene: slice[slice.length - 1].scene_num,
        count: slice.length,
        promptText: slice.map(sc => `scene${sc.scene_num}: ${sc.image_prompt}`).join("\n\n")
      });
    }

    const totalBatches = prebuiltBatches.length;
    const startBatchIdx = job.flow_completed_batches || 0;

    for (let bIdx = startBatchIdx; bIdx < totalBatches; bIdx++) {
      if (!(await checkBackendStillRunning())) return;

      // Extra safety: NEVER paste next batch until previous batch has 100% finished renaming & arrow_forward is back!
      while (isFlowAgentBusy()) {
        if (!(await checkBackendStillRunning())) return;
        await new Promise(r => setTimeout(r, 1000));
      }

      const batch = prebuiltBatches[bIdx];
      const feedbackBefore = countSidebarFeedbackBars();
      const errorsBeforeBatch = countFlowSomethingWentWrongErrors();
      const lastSceneTag = `scene${batch.endScene}`;

      sendStatus(
        "RUNNING",
        `Step 5/7: Flow Generating & Renaming Batch ${bIdx + 1}/${totalBatches} (Scenes ${batch.startScene}–${batch.endScene} of ${scenes.length})...`,
        `Waiting until Flow finishes generating AND renaming all ${batch.count} scenes (${lastSceneTag}) before sending next batch...`
      );

      let editor = document.querySelector('div.ProseMirror[contenteditable="true"], div[role="textbox"][contenteditable="true"]');
      if (!editor) {
        sendStatus("PROBLEM", "⚠️ Problem: Flow Input Box Disappeared", "Could not find prompt editor for next batch.", true);
        return;
      }

      injectProseMirrorText(editor, batch.promptText);
      const batchSent = await sendFlowPromptAtomProof(editor);
      if (!batchSent) {
        if (await checkBackendStillRunning()) {
          sendStatus("PROBLEM", `⚠️ Problem: Could Not Send Batch ${bIdx + 1}`, `Send button did not trigger for Scenes ${batch.startScene}–${batch.endScene}.`, true);
        }
        return;
      }

      // Wait until Flow Agent COMPLETELY finishes generating AND renaming all scenes in this batch:
      // 1) isFlowAgentBusy() MUST be false (Stop square gone AND arrow_forward send button visible again)
      // 2) A new feedback bar (thumb_up/copy) MUST appear after the completion message!
      await new Promise(r => setTimeout(r, 6000));
      let batchDone = false;

      for (let tick = 0; tick < 450; tick++) {
        if (!(await checkBackendStillRunning())) return;
        await new Promise(r => setTimeout(r, 2000));

        // Still generating or renaming (square Stop icon active or arrow_forward missing) -> KEEP WAITING!
        if (isFlowAgentBusy()) continue;

        if (countFlowSomethingWentWrongErrors() > errorsBeforeBatch) {
          await handleFlowErrorWithSingleReload(job, `batch_${bIdx}`, `Batch ${bIdx + 1} (Scenes ${batch.startScene}–${batch.endScene})`);
          return;
        }

        const feedbackNow = countSidebarFeedbackBars();
        if (feedbackNow > feedbackBefore) {
          // Confirm arrow_forward stayed stable for 1.5s (not a momentary transition between generate & rename)
          await new Promise(r => setTimeout(r, 1500));
          if (!isFlowAgentBusy()) {
            batchDone = true;
            job.flow_completed_batches = bIdx + 1;
            await chrome.storage.local.set({ vorvex_job: job });
            break;
          }
        }
      }

      if (!batchDone) {
        sendStatus("PROBLEM", `⚠️ Problem: Batch ${bIdx + 1} Timed Out`, `Google Flow took too long on Scenes ${batch.startScene}–${batch.endScene}.`, true);
        return;
      }
    }

    // 6. All 100% images generated & renamed! Reload page once cleanly before ZIP download
    sendStatus("RUNNING", "Step 6/7: All Images Generated & Renamed! Refreshing Page Before ZIP Download...", "Reloading Google Flow page once so 100% of generated images sync cleanly before downloading ZIP...");
    job.stage = "FLOW_RELOADED_DOWNLOAD";
    await chrome.storage.local.set({ vorvex_job: job });
    await new Promise(r => setTimeout(r, 1500));
    window.location.reload();
  }

  setTimeout(runFlowBrain, 1200);
})();