// Direct instant bridge inside VORVEX Studio tab (with retry loop so it never misses a job)
window.addEventListener("VORVEX_LAUNCH_AGENT", async () => {
  for (let attempt = 0; attempt < 20; attempt++) {
    try {
      const res = await fetch("http://127.0.0.1:7865/poll_job");
      if (res.ok) {
        const job = await res.json();
        if (job && job.active && job.job_id) {
          chrome.runtime.sendMessage({
            type: "START_JOB_DIRECT",
            payload: job
          });
          return;
        }
      }
    } catch (err) {}
    await new Promise((r) => setTimeout(r, 250));
  }
});

document.documentElement.setAttribute("data-vorvex-ext", "ready");